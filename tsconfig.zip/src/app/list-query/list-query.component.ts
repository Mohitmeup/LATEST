import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {BankerServiceService} from '../service/banker-service.service';
import { CaseidBean } from '../model/caseid-bean';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-list-query',
  templateUrl: './list-query.component.html',
  styleUrls: ['./list-query.component.css']
})


export class ListQueryComponent implements OnInit {
  bean: CaseidBean[];
  constructor(private route:Router ,private bankerService:BankerServiceService ) { }

  ngOnInit() {
    this.load()
  }
  load() {
    console.log("enter1");
    const bankerid1=localStorage.getItem("bankerid");
    var bankerId = Number(bankerid1)
    console.log(bankerId)
    let banker={
      bankerId
    }
    this.bankerService.newDebitQuery(banker).subscribe(
    
      (data) => {
        console.log("enter"); 
        console.log(data)
      

  
        this.bean = data;
       
       
     
    }
      );
}


replyrr(caseIdTotal:string){
Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Approve',
  cancelButtonText: 'Dis-approve',
  reverseButtons: true
}).then((result) => {
  if (result.value) {
    console.log("fgffbcbdfgbdfgg")
    Swal.fire({
      input:'text',
      icon: 'warning',
      title: 'Reply Query',
      text: "Enter your remarks"
    }).then((result) => {
    const bankAdminRemarks1=JSON.stringify(result.value)
    console.log(bankAdminRemarks1)
    var statusOfServiceRequest='Approved'
    let banker={
      caseIdTotal,
      bankAdminRemarks1,
      statusOfServiceRequest
      
    }
    console.log(banker)
    console.log("fgdf")
    this.bankerService.replyQuery(banker).subscribe(
      (data) => {
        console.log("enter33333");
      } )
  })
 } else if (
    /* Read more about handling dismissals below */
    result.dismiss === Swal.DismissReason.cancel
  ) { Swal.fire({
    input:'text',
    icon: 'warning',
    title: 'Reply Query',
    text: "Enter your remarks"
  }).then((result) => {
  const bankAdminRemarks=result.value
  console.log(bankAdminRemarks)
  var statusOfServiceRequest='Approved'
  let banker={
    caseIdTotal,
    bankAdminRemarks,
    statusOfServiceRequest
    
  }
  console.log(banker)
  console.log("fgdf")
  this.bankerService.replyQuery(banker).subscribe(
    (data) => {
      console.log("enter33333");
    } )
})
}
})}



              }
   
  