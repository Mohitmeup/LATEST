import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {BankerServiceService} from '../service/banker-service.service';
import { CaseidBean } from '../model/caseid-bean';
@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {
  bean: CaseidBean[];

  constructor(private route:Router ,private bankerService:BankerServiceService ){ 
  }
    selectedlevel;
  

  ngOnInit() {
  }
selected(){

console.log(this.selectedlevel)


}

newDebitQuery(){
var bankerid=this.selectedlevel
    localStorage.setItem("bankerid",bankerid.toString());
    this.route.navigateByUrl("/banker/viewnewDebitQueries");


}

newCreditQuery(){
  var bankerid=this.selectedlevel
  localStorage.setItem("bankerid",bankerid.toString());
  this.route.navigateByUrl("/banker/viewCreditQueries");

}

viewDebitUpgradeQuery(){
  var bankerid=this.selectedlevel
  localStorage.setItem("bankerid",bankerid.toString());
  this.route.navigateByUrl("/banker/viewUpgradeDebitQueries");

}

viewCreditUpgradeQuery(){
  var bankerid=this.selectedlevel
  localStorage.setItem("bankerid",bankerid.toString());
  this.route.navigateByUrl("/banker/viewUpgradeCreditQueries");

}

viewDebitMismatchQuery(){
  var bankerid=this.selectedlevel
  localStorage.setItem("bankerid",bankerid.toString());
  this.route.navigateByUrl("/banker/viewDebitMismatchQueries");

}

viewCreditMismatchQuery(){
  var bankerid=this.selectedlevel
  localStorage.setItem("bankerid",bankerid.toString());
  this.route.navigateByUrl("/banker/viewCreditMismatchQueries");


}
viewCustomerHistory(){
  
  this.route.navigateByUrl("/banker/viewCustomerHistory");


}

}
