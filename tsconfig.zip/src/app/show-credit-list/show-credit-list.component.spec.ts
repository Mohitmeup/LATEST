import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowCreditListComponent } from './show-credit-list.component';

describe('ShowCreditListComponent', () => {
  let component: ShowCreditListComponent;
  let fixture: ComponentFixture<ShowCreditListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowCreditListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowCreditListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
