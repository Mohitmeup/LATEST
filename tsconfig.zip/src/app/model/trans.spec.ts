import { Trans } from './trans';

describe('Trans', () => {
  it('should create an instance', () => {
    expect(new Trans()).toBeTruthy();
  });
});
