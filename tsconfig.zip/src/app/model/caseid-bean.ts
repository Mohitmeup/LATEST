export class CaseidBean {
    public caseIdTotal:String;    
    public applicationId:number ;   
    public caseTimeStamp:Date;   
    public requestMap:string; 
    public statusOfServiceRequest:string;   
    public accountNumber:number ;   
    public bankTimeStamp:Date ;    
    public defineServiceRequest:string;
   public cardNumber:number;
   public customerReferenceId:string;
   public customerRemarks:string;
   public bankAdminRemarks:string
    }



