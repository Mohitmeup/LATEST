import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCreditMismatchRequestsComponent } from './list-credit-mismatch-requests.component';

describe('ListCreditMismatchRequestsComponent', () => {
  let component: ListCreditMismatchRequestsComponent;
  let fixture: ComponentFixture<ListCreditMismatchRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListCreditMismatchRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCreditMismatchRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
