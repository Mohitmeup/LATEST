import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BankerServiceService {
  [x: string]: any;
  baseUrl: string;
  baseUrl1: string;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/banker`;
    this.baseUrl1 = `${environment.baseMwUrl}`;
  }

 
  newDebitQuery( banker:any){
    return this.http.post<any>(`${this.baseUrl}/viewNewdebit`,banker);}
    newCreditQuery( banker:any){
      return this.http.post<any>(`${this.baseUrl}/viewNewcredit`,banker);}
      UpgradeDebitQuery( banker:any){
        return this.http.post<any>(`${this.baseUrl}/viewUpgradeDebit`,banker);}
    
        UpgradeCreditQuery( banker:any){
          return this.http.post<any>(`${this.baseUrl}/viewUpgradeCredit`,banker);}
          DebitMismatchQuery( banker:any){
            return this.http.post<any>(`${this.baseUrl}/viewDebitmismatch`,banker);} 
            CreditMismatchQuery( banker:any){
              return this.http.post<any>(`${this.baseUrl}/viewCreditmismatch`,banker);}

              
replyQuery(banker:any){
  return this.http.post<any>(`${this.baseUrl}/replyQueries`,banker);
}

  viewRequests(){
    return this.http.get<any>(`${this.baseUrl1}/queryStatus`);

  }

  viewCustomerHistory(){
    return this.http.get<any>(`${this.baseUrl}/viewCustomerHistory`);
  }


showDebitTransaction(CaseIdObj:any){
  return this.http.post<any>(`${this.baseUrl}/debitQueriesMismatch`,CaseIdObj);

}
blockCard(cardDetails: any){
return this.http.post<any>(`${this.baseUrl}/mismatchDebitBlock`,cardDetails);

}
  }

 

