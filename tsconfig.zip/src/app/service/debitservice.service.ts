import { Injectable } from '@angular/core';
import { Debitmodel } from '../model/debitmodel';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DebitserviceService {
  [x: string]: any;
  baseUrl: string;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/debit`;
  }

  getAll(): Observable<any> {
    console.log("abc")
    return this.http.get<any>(`${this.baseUrl}/debitlist`);

  }

  getDetails(cardDetails: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/carddisplaymenu`,cardDetails);
  }
  blockCard(cardDetails: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/block`,cardDetails);
  }
  activateCard(cardDetails:any):Observable<any>{
    return this.http.patch<any>(`${this.baseUrl}/activate`,cardDetails);
  }
  deactivateCard(cardDetails:any):Observable<any>{
    return this.http.patch<any>(`${this.baseUrl}/deactivate`,cardDetails);
  }
  resetCard1(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/reset`,cardDetails);
  }
  resetCard2(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.patch<any>(`${this.baseUrl}/resetpin`,cardDetails);
  }
  upgrade1(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/upgrade`,cardDetails);
  }
  upgrade2(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/upgrade2`,cardDetails);
  }

  check(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/check`,cardDetails);
  }

  checkActive(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/checkactive`,cardDetails);
  }

  getAllTransactions(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    console.log("fdf")
    return this.http.post<any>(`${this.baseUrl}/getAllTransactions`,cardDetails);
  }


  getTransactions(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    console.log("fdf")
    return this.http.post<any>(`${this.baseUrl}/requestStatement`,cardDetails);
  }

  report(cardDetails:any):Observable<any>{
    console.log(cardDetails)
    return this.http.post<any>(`${this.baseUrl}/mismatchDebit`,cardDetails);
  }
 applyNewDebitCard(cardDetails:any):Observable<any>{

  console.log(cardDetails)
  return this.http.post<any>(`${this.baseUrl}/applynewdebit`,cardDetails);

 }
  
}